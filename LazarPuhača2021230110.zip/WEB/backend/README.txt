Open in terminal
"npm install" to install modules


