const express = require('express');
const mongoose = require('mongoose');
const app = express();
const morgan = require('morgan');

const api = process.env.API_URL;

app.post(`${api}/travelproducts`, (req,res) =>{

    const product =new Destination({
        name: req.body.name,
        image: req.body.image,
        countTravelers: req.body.countTravelers
    })
    product.save().then((createdDestination => {
        res.status(201).json(createdDestination)
    })).catch((err) =>{
        res.status(500).json({
            error: err,
            success: false
        })
    })
})