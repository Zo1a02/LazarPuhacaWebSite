Open in terminal
"npm install" to install modules
"ng serve" to start a frontend and write localhost:4200 to enter site

